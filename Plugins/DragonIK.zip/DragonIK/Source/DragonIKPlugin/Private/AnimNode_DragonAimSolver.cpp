/* Copyright (C) Gamasome Interactive LLP, Inc - All Rights Reserved
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential
* Written by Mansoor Pathiyanthra <codehawk64@gmail.com , mansoor@gamasome.com>, July 2018
*/


#include "AnimNode_DragonAimSolver.h"
#include "DragonIKPlugin.h"
#include "Animation/AnimInstanceProxy.h"
#include "DrawDebugHelpers.h"
#include "AnimationRuntime.h"
#include "AnimationCoreLibrary.h"
#include "Algo/Reverse.h"






// Initialize the component pose as well as defining the owning skeleton
void FAnimNode_DragonAimSolver::Initialize_AnyThread(const FAnimationInitializeContext & Context)
{
	FAnimNode_DragonControlBase::Initialize_AnyThread(Context);
//	ComponentPose.Initialize(Context);
	owning_skel = Context.AnimInstanceProxy->GetSkelMeshComponent();




	//	dragon_bone_data.Start_Spine = FBoneReference(dragon_input_data.Start_Spine);
}


/*
// Cache the bones . Thats it !!
void FAnimNode_DragonAimSolver::CacheBones_AnyThread(const FAnimationCacheBonesContext & Context)
{
	FAnimNode_Base::CacheBones_AnyThread(Context);
	ComponentPose.CacheBones(Context);
	InitializeBoneReferences(Context.AnimInstanceProxy->GetRequiredBones());
}
*/









void FAnimNode_DragonAimSolver::Make_All_Bones(FCSPose<FCompactPose>& MeshBases)
{


	const FBoneContainer& BoneContainer = MeshBases.GetPose().GetBoneContainer();

	TArray<FCompactPoseBoneIndex> BoneIndices;

	{
		const FCompactPoseBoneIndex RootIndex = spine_Feet_pair[0].Spine_Involved.GetCompactPoseIndex(BoneContainer);
		FCompactPoseBoneIndex BoneIndex = spine_Feet_pair[spine_Feet_pair.Num()-1].Spine_Involved.GetCompactPoseIndex(BoneContainer);
		do
		{
			BoneIndices.Insert(BoneIndex, 0);
			BoneIndex = MeshBases.GetPose().GetParentBoneIndex(BoneIndex);
		} while (BoneIndex != RootIndex);
		BoneIndices.Insert(BoneIndex, 0);
	}

	combined_indices = BoneIndices;
}






// Store the animated and calculated pose transform data
void FAnimNode_DragonAimSolver::GetAnimatedPoseInfo(FCSPose<FCompactPose>& MeshBases, TArray<FBoneTransform>& OutBoneTransforms)
{
	int32 const NumTransforms = combined_indices.Num();
	OutBoneTransforms = TArray<FBoneTransform>();



	//FVector Overall_PostSolved_Offset_Temp = Overall_PostSolved_Offset;

	//Overall_PostSolved_Offset_Temp = owning_skel->GetComponentToWorld().TransformVector(Overall_PostSolved_Offset_Temp);

	//FVector Overall_PostSolved_Offset = Overall_PostSolved_Offset_Temp;


//	if(owning_skel->GetWorld()->IsGameWorld())
	{



		for (int i = 0; i < HeadTransforms.Num(); i++)
		{
			OutBoneTransforms.Add(HeadTransforms[i]);
		}

		for (int i = 0; i < LegIK_Transforms.Num(); i++)
		{
			OutBoneTransforms.Add(LegIK_Transforms[i]);
		}



		for (int i = 0; i < HandIK_Transforms.Num(); i++)
		{
			OutBoneTransforms.Add(HandIK_Transforms[i]);
		}




		for (int boneindex = 0; boneindex < OutBoneTransforms.Num() ; boneindex++)
		{

		

			FTransform original_transform = MeshBases.GetComponentSpaceTransform(OutBoneTransforms[boneindex].BoneIndex);
			OutBoneTransforms[boneindex].Transform = UKismetMathLibrary::TLerp(original_transform,OutBoneTransforms[boneindex].Transform,toggle_alpha);


		}


	if (enable_solver)
	{




	}
	else
	{


	}



	}

}




void FAnimNode_DragonAimSolver::Evaluate_AnyThread(FPoseContext & Output)
{
}





void FAnimNode_DragonAimSolver::ConditionalDebugDraw(FPrimitiveDrawInterface* PDI, USkeletalMeshComponent* PreviewSkelMeshComp) const
{
	
#if WITH_EDITORONLY_DATA
	if (PreviewSkelMeshComp && PreviewSkelMeshComp->GetWorld())
	{
		

	}
#endif

}

//Perform update operations inside this
void FAnimNode_DragonAimSolver::UpdateInternal(const FAnimationUpdateContext & Context)
{
	FAnimNode_DragonControlBase::UpdateInternal(Context);


	if (enable_solver)
		toggle_alpha = UKismetMathLibrary::Lerp(toggle_alpha, 1, owning_skel->GetWorld()->GetDeltaSeconds() * Toggle_Interpolation_Speed);
	else
		toggle_alpha = UKismetMathLibrary::Lerp(toggle_alpha, 0, owning_skel->GetWorld()->GetDeltaSeconds() * Toggle_Interpolation_Speed);



	TraceStartList.Empty();
	TraceEndList.Empty();


	if (test_counter < 500)
	test_counter++;



	trace_draw_counter++;

	if (trace_draw_counter > 5)
		trace_draw_counter = 0;



	component_scale = owning_skel->GetComponentTransform().GetScale3D().Z;



}






FName FAnimNode_DragonAimSolver::GetChildBone(FName BoneName, USkeletalMeshComponent* skel_mesh)
{

	FName child_bone = skel_mesh->GetBoneName(skel_mesh->GetBoneIndex(BoneName) +1);
		
	return child_bone;
	
}


//Nothing would be needed here
void FAnimNode_DragonAimSolver::EvaluateComponentSpaceInternal(FComponentSpacePoseContext & Context)
{
}



void FAnimNode_DragonAimSolver::EvaluateSkeletalControl_AnyThread(FComponentSpacePoseContext& Output, TArray<FBoneTransform>& OutBoneTransforms)
{
	TArray<FBoneTransform> BoneTransforms_input = TArray<FBoneTransform>();


	for (int spine_index = 0; spine_index < dragon_input_data.FeetBones.Num(); spine_index++)
	{
		FBoneReference knee_bone_ref = FBoneReference(dragon_input_data.FeetBones[spine_index].Knee_Bone_Name);

		
		if (automatic_leg_make == true)
		{
			knee_bone_ref = FBoneReference(dragon_input_data.FeetBones[spine_index].Feet_Bone_Name);
		}

		knee_bone_ref.Initialize(*SavedBoneContainer);

		if (knee_bone_ref.IsValidToEvaluate())
		{
			if (automatic_leg_make == true)
			{
				if (knee_Animated_transform_array.Num() > spine_index)
					knee_Animated_transform_array[spine_index] = Output.Pose.GetComponentSpaceTransform((*SavedBoneContainer).GetParentBoneIndex(knee_bone_ref.CachedCompactPoseIndex));

			}
			else
			{
				if (knee_Animated_transform_array.Num() > spine_index)
					knee_Animated_transform_array[spine_index] = Output.Pose.GetComponentSpaceTransform(knee_bone_ref.CachedCompactPoseIndex);
			}
		}
	}



	FABRIK_BodySystem( Output.Pose,Output, BoneTransforms_input);

	GetAnimatedPoseInfo(Output.Pose, OutBoneTransforms);


}





bool FAnimNode_DragonAimSolver::IsValidToEvaluate(const USkeleton * Skeleton, const FBoneContainer & RequiredBones)
{


	//return true;

	bool feet_is_true = true;



	for (int i = 0; i < dragon_input_data.FeetBones.Num(); i++)
	{
		//dragon_bone_data.FeetBones[i] = FBoneReference(dragon_input_data.FeetBones[i]);
		//dragon_bone_data.FeetBones.Add(FBoneReference(dragon_input_data.FeetBones[i].Feet_Bone_Name));
		//dragon_bone_data.FeetBones[i].Initialize(RequiredBones);


		//GEngine->AddOnScreenDebugMessage(-1, 5.01f, FColor::Red, "Is single spine "+ dragon_input_data.FeetBones[i].Feet_Bone_Name.ToString());


		FBoneReference foot_bone_ref = FBoneReference(dragon_input_data.FeetBones[i].Feet_Bone_Name);
		foot_bone_ref.Initialize(RequiredBones);


		FBoneReference knee_bone_ref = FBoneReference(dragon_input_data.FeetBones[i].Knee_Bone_Name);
		knee_bone_ref.Initialize(RequiredBones);


		FBoneReference thigh_bone_ref = FBoneReference(dragon_input_data.FeetBones[i].Thigh_Bone_Name);
		thigh_bone_ref.Initialize(RequiredBones);


		if (!automatic_leg_make)
		{
			if (knee_bone_ref.IsValidToEvaluate(RequiredBones) == false || thigh_bone_ref.IsValidToEvaluate(RequiredBones) == false)
				feet_is_true = false;
		}

		//if (dragon_bone_data.FeetBones.Num() == dragon_input_data.FeetBones.Num())
		if (foot_bone_ref.IsValidToEvaluate(RequiredBones) == false)
			feet_is_true = false;


	}

	/*
	for (int i = 0; i < dragon_bone_data.FeetBones.Num(); i++)
	{

		if (dragon_bone_data.FeetBones.Num() == dragon_input_data.FeetBones.Num())
			if (FBoneReference(dragon_bone_data.FeetBones[i]).IsValidToEvaluate(RequiredBones) == false)
			{
				feet_is_true = false;
			}

	}*/



	FBoneReference Pelvis_ref = FBoneReference(dragon_input_data.Pelvis);
	Pelvis_ref.Initialize(RequiredBones);


	FBoneReference Chest_ref = FBoneReference(dragon_input_data.Start_Spine);
	Chest_ref.Initialize(RequiredBones);




	bool look_at_fine = true;

	if (enable_solver)
	{
	//	look_at_fine = Head_ref.IsValidToEvaluate(RequiredBones);




	}
		
	if(dragon_bone_data.Pelvis.IsValidToEvaluate(RequiredBones) || dragon_bone_data.Start_Spine.IsValidToEvaluate(RequiredBones))
	{
		return (RequiredBones.BoneIsChildOf(FBoneReference(dragon_bone_data.Start_Spine).BoneIndex, FBoneReference(dragon_bone_data.Pelvis).BoneIndex) &&  EndSplineBone.IsValidToEvaluate(RequiredBones) && StartSplineBone.IsValidToEvaluate(RequiredBones) && RequiredBones.IsValid() && (RequiredBones.BoneIsChildOf(EndSplineBone.BoneIndex, StartSplineBone.BoneIndex)));
	}

	return (EndSplineBone.IsValidToEvaluate(RequiredBones) && StartSplineBone.IsValidToEvaluate(RequiredBones) && RequiredBones.IsValid()&& (RequiredBones.BoneIsChildOf(EndSplineBone.BoneIndex, StartSplineBone.BoneIndex)));


	/*
	return (EndSplineBone.IsValidToEvaluate(RequiredBones) && StartSplineBone.IsValidToEvaluate(RequiredBones) && RequiredBones.IsValid()&&solve_should_fail == false && feet_is_true && dragon_input_data.FeetBones.Num()%2==0&&
		feet_is_empty==false&& Chest_ref.IsValidToEvaluate(RequiredBones) &&
		Pelvis_ref.IsValidToEvaluate(RequiredBones)&&
		RequiredBones.BoneIsChildOf(EndSplineBone.BoneIndex, StartSplineBone.BoneIndex));
		*/

	//return false;

}


// SPLINE IK CODE INITIALIZATION CODE


// SPLINE IK CODE END





FAnimNode_DragonAimSolver::FAnimNode_DragonAimSolver()
{


	Lerped_LookatLocation = FVector::ZeroVector;

	FRichCurve* Look_Bending_CurveData = Look_Bending_Curve.GetRichCurve();
	Look_Bending_CurveData->AddKey(0.f, 0.025f);
	Look_Bending_CurveData->AddKey(1.f, 1.f);


	FRichCurve* Look_Multiplier_CurveData = Look_Multiplier_Curve.GetRichCurve();
	Look_Multiplier_CurveData->AddKey(0.f, 1.0f);
	Look_Multiplier_CurveData->AddKey(1.f, 1.0f);


	LookAt_Axis = FVector(0,1,0);
	//LookAt_Axis.bInLocalSpace = false;


	Debug_LookAtLocation.SetLocation(FVector(0,200,100));

}


void FAnimNode_DragonAimSolver::InitializeBoneReferences(FBoneContainer & RequiredBones)
{


	SavedBoneContainer = &RequiredBones;


	solve_should_fail = false;

	if (dragon_input_data.Start_Spine == dragon_input_data.Pelvis)
	{
		solve_should_fail = true;
	}

	dragon_bone_data.Start_Spine = FBoneReference(dragon_input_data.Start_Spine);
	dragon_bone_data.Start_Spine.Initialize(RequiredBones);

	dragon_bone_data.Pelvis = FBoneReference(dragon_input_data.Pelvis);
	dragon_bone_data.Pelvis.Initialize(RequiredBones);

	if (!RequiredBones.BoneIsChildOf(FBoneReference(dragon_bone_data.Start_Spine).BoneIndex, FBoneReference(dragon_bone_data.Pelvis).BoneIndex))
	{
		solve_should_fail = true;
	}



	EndSplineBone.Initialize(*SavedBoneContainer);
	StartSplineBone.Initialize(*SavedBoneContainer);

	Hand_Array.Empty();
	Elbow_Array.Empty();
	Shoulder_Array.Empty();
	Actual_Shoulder_Array.Empty();



	for (int i = 0; i < Aiming_Hand_Limbs.Num(); i++)
	{

		/*
		Hand_Array.Add(Aiming_Hand_Limbs[i].Hand_Bone_Name);
		Elbow_Array.Add(Aiming_Hand_Limbs[i].Elbow_Bone_Name);
		Shoulder_Array.Add(Aiming_Hand_Limbs[i].Shoulder_Bone_Name);
		Actual_Shoulder_Array.Add(Aiming_Hand_Limbs[i].Shoulder_Bone_Name);



		Hand_Array[i].Initialize(*SavedBoneContainer);
		Elbow_Array[i].Initialize(*SavedBoneContainer);
		Shoulder_Array[i].Initialize(*SavedBoneContainer);
		Actual_Shoulder_Array[i].Initialize(*SavedBoneContainer);
		*/

		Hand_Array.Add(Aiming_Hand_Limbs[i].Hand_Bone_Name);
		Elbow_Array.Add(Aiming_Hand_Limbs[i].Elbow_Bone_Name);
		Shoulder_Array.Add(Aiming_Hand_Limbs[i].Shoulder_Bone_Name);
		Actual_Shoulder_Array.Add(Aiming_Hand_Limbs[i].Shoulder_Bone_Name);

		Hand_Array[i].Initialize(*SavedBoneContainer);
		Elbow_Array[i].Initialize(*SavedBoneContainer);
		Shoulder_Array[i].Initialize(*SavedBoneContainer);
		Actual_Shoulder_Array[i].Initialize(*SavedBoneContainer);


	}


	
	//if (test_counter < 10 && solve_should_fail==false)

	if(solve_should_fail == false)
	{

	
		spine_Feet_pair.Empty();
		Total_spine_bones.Empty();





		//if (spine_AnimatedTransform_pairs.Num() == 0)
		if (test_counter < 10)
		{
					
			spine_Transform_pairs.Empty();

			spine_AnimatedTransform_pairs.Empty();
			
			spine_hit_pairs.Empty();

			spine_LocDifference.Empty();

			spine_RotDifference.Empty();


			Total_spine_heights.Empty();

			Total_spine_alphas.Empty();

			spine_hit_between.Empty();

			spine_hit_edges.Empty();

			knee_Animated_transform_array.Empty();

		}


		Total_spine_bones = BoneArrayMachine(0, dragon_input_data.Start_Spine,"","", dragon_input_data.Pelvis, false);

		Algo::Reverse(Total_spine_bones);

		solve_should_fail = false;

		//	spine_Feet_pair.AddDefaulted(Total_spine_bones.Num());





		for (int32 i = 0; i < dragon_input_data.FeetBones.Num(); i++)
		{

			for (int32 j = 0; j < dragon_input_data.FeetBones.Num(); j++)
			{
				if (i != j)
				{
					if (dragon_input_data.FeetBones[i].Feet_Bone_Name == dragon_input_data.FeetBones[j].Feet_Bone_Name)
					{
						solve_should_fail = true;
					}
				}
			}

			BoneArrayMachine(i, dragon_input_data.FeetBones[i].Feet_Bone_Name, dragon_input_data.FeetBones[i].Knee_Bone_Name, dragon_input_data.FeetBones[i].Thigh_Bone_Name, dragon_input_data.Pelvis, true);

		}
		Spine_Indices.Empty();


		



		Total_spine_angles.Empty();
		Total_Terrain_Locations.Empty();

		const TArray<FDragonData_SpineFeetPair> const_feet_pair = spine_Feet_pair;

		if(test_counter<10)
		Total_spine_alphas.AddDefaulted(const_feet_pair.Num());

		for (int32 i = 0; i < const_feet_pair.Num(); i++)
		{
			if (test_counter < 10)
			Total_spine_alphas[i] = 0;

			if (const_feet_pair[i].Associated_Feet.Num() == 0 && i < const_feet_pair.Num())
				spine_Feet_pair.Remove(const_feet_pair[i]);



		}

		spine_Feet_pair.Shrink();







		if (spine_Feet_pair.Num() == 1)
		{

			FDragonData_SpineFeetPair data = FDragonData_SpineFeetPair();
			data.Spine_Involved = FBoneReference(Total_spine_bones[Total_spine_bones.Num() - 1]);
			data.Spine_Involved.Initialize(*SavedBoneContainer);

			spine_Feet_pair.Add(data);



			bool is_swapped = false;

			

		}
		else
		{
			spine_Feet_pair = Swap_Spine_Pairs(spine_Feet_pair);

		}



		/*
		for (int i = 0; i < spine_Feet_pair.Num(); i++)
		{
			for (int j = 0; j < spine_Feet_pair[i].Associated_Feet.Num(); j++)
			{

				GEngine->AddOnScreenDebugMessage(-1, 20.01f, FColor::Red, "- Bone Feet : " + spine_Feet_pair[i].Associated_Feet[j].BoneName.ToString());
				GEngine->AddOnScreenDebugMessage(-1, 20.01f, FColor::Red, "- Knee Feet : " + spine_Feet_pair[i].Associated_Knees[j].BoneName.ToString());
				GEngine->AddOnScreenDebugMessage(-1, 20.01f, FColor::Red, "- Thigh Feet : " + spine_Feet_pair[i].Associated_Thighs[j].BoneName.ToString());
				GEngine->AddOnScreenDebugMessage(-1, 20.01f, FColor::Red, " -///////////////- " + spine_Feet_pair[i].Associated_Thighs[j].BoneName.ToString());
			}
		}
		*/
		/*
		dragon_bone_data.Start_Spine = FBoneReference(dragon_input_data.Start_Spine);
		dragon_bone_data.Start_Spine.Initialize(RequiredBones);



		dragon_bone_data.Pelvis = FBoneReference(dragon_input_data.Pelvis);
		dragon_bone_data.Pelvis.Initialize(RequiredBones);
		*/






		if (test_counter < 10)
		{
			spine_hit_pairs.AddDefaulted(spine_Feet_pair.Num());

			//if (spine_Transform_pairs.Num() == 0)
			spine_Transform_pairs.AddDefaulted(spine_Feet_pair.Num());

			//if(spine_AnimatedTransform_pairs.Num() == 0)
			spine_AnimatedTransform_pairs.AddDefaulted(spine_Feet_pair.Num());

			Total_spine_angles.AddDefaulted(spine_Feet_pair.Num());
			Total_Terrain_Locations.AddDefaulted(spine_Feet_pair.Num());
			spine_LocDifference.AddDefaulted(spine_Feet_pair.Num());
			spine_RotDifference.AddDefaulted(spine_Feet_pair.Num());

			knee_Animated_transform_array.AddDefaulted(dragon_input_data.FeetBones.Num());

		}



		//	Total_spine_alphas.AddDefaulted(spine_Feet_pair.Num());



	//	spine_hit_between.AddDefaulted(7);










		for (int32 i = 0; i < spine_Feet_pair.Num(); i++)
		{


		//	spine_Feet_pair[i].Associated_Knees.AddUninitialized(spine_Feet_pair[i].Associated_Feet.Num());
		//	spine_Feet_pair[i].Associated_Thighs.AddUninitialized(spine_Feet_pair[i].Associated_Feet.Num());






			every_foot_dont_have_child = false;
			feet_is_empty = true;



			//	GEngine->AddOnScreenDebugMessage(-1, 0.01f, FColor::Red, "Child Bone " + GetChildBone(spine_Feet_pair[i].Associated_Feet[j].BoneName, owning_skel).ToString());

			for (int32 j = 0; j < spine_Feet_pair[i].Associated_Feet.Num(); j++)
			{

				FName child_name = GetChildBone(spine_Feet_pair[i].Associated_Feet[j].BoneName, owning_skel);

				

				FBoneReference Knee_Involved = FBoneReference(owning_skel->GetParentBone(spine_Feet_pair[i].Associated_Feet[j].BoneName));
				Knee_Involved.Initialize(*SavedBoneContainer);

			//	spine_Feet_pair[i].Associated_Knees[j] = Knee_Involved;


			}


			spine_Feet_pair[i].Feet_Heights.AddDefaulted(spine_Feet_pair[i].Associated_Feet.Num());

			

			if (test_counter < 10)
			{
				spine_hit_pairs[i].RV_Feet_Hits.AddDefaulted(spine_Feet_pair[i].Associated_Feet.Num());
				spine_hit_pairs[i].RV_FeetBalls_Hits.AddDefaulted(spine_Feet_pair[i].Associated_Feet.Num());
				spine_hit_pairs[i].RV_Knee_Hits.AddDefaulted(spine_Feet_pair[i].Associated_Feet.Num());


				//if (spine_Transform_pairs.Num() == 0)
				{
					spine_Transform_pairs[i].Associated_Feet.AddDefaulted(spine_Feet_pair[i].Associated_Feet.Num());

					spine_Transform_pairs[i].Associated_Knee.AddDefaulted(spine_Feet_pair[i].Associated_Feet.Num());

					spine_Transform_pairs[i].Associated_FeetBalls.AddDefaulted(spine_Feet_pair[i].Associated_Feet.Num());
				}

				//if (spine_AnimatedTransform_pairs.Num() == 0)
				{
					spine_AnimatedTransform_pairs[i].Associated_Feet.AddDefaulted(spine_Feet_pair[i].Associated_Feet.Num());

					spine_AnimatedTransform_pairs[i].Associated_Knee.AddDefaulted(spine_Feet_pair[i].Associated_Feet.Num());

					spine_AnimatedTransform_pairs[i].Associated_FeetBalls.AddDefaulted(spine_Feet_pair[i].Associated_Feet.Num());
				}
			}

			if (spine_Feet_pair[i].Associated_Feet.Num() > 0)
			{
				feet_is_empty = false;
			}

		}






		if (dragon_input_data.Start_Spine == dragon_input_data.Pelvis)
			solve_should_fail = true;

		if (spine_Feet_pair.Num() > 0)
		{
			if (spine_Feet_pair[0].Spine_Involved.BoneIndex > spine_Feet_pair[spine_Feet_pair.Num() - 1].Spine_Involved.BoneIndex)
				solve_should_fail = true;
		}

		if (!dragon_bone_data.Start_Spine.IsValidToEvaluate(RequiredBones) || !dragon_bone_data.Pelvis.IsValidToEvaluate(RequiredBones))
			solve_should_fail = true;



		Extra_Spine_Indices.Empty();


		if (spine_Feet_pair.Num() > 0)
		{
			spine_Feet_pair[0].Spine_Involved = dragon_bone_data.Pelvis;

			if (spine_Feet_pair.Num() > 1)
				spine_Feet_pair[spine_Feet_pair.Num() - 1].Spine_Involved = dragon_bone_data.Start_Spine;
		}

	//	if(enable_solver)
	//	Extra_Spine_Indices.Add(dragon_bone_data.Head_Bone.GetCompactPoseIndex(RequiredBones));

		for (int32 i = 0; i < Total_spine_bones.Num(); i++)
		{
			FBoneReference bone_ref = FBoneReference(Total_spine_bones[i]);
			bone_ref.Initialize(RequiredBones);

			if (spine_Feet_pair.Num() > 0)
			{
				if (bone_ref.BoneIndex >= spine_Feet_pair[0].Spine_Involved.BoneIndex && bone_ref.BoneIndex <= spine_Feet_pair[spine_Feet_pair.Num() - 1].Spine_Involved.BoneIndex)
					Spine_Indices.Add(bone_ref.GetCompactPoseIndex(RequiredBones));
				else
				{
					Extra_Spine_Indices.Add(bone_ref.GetCompactPoseIndex(RequiredBones));

					//				GEngine->AddOnScreenDebugMessage(-1, 4.01f, FColor::Red, "Extra Bone " + FString::SanitizeFloat(Extra_Spine_Indices[i].GetInt()) );

				}


			}
			else
			{
				Spine_Indices.Add(bone_ref.GetCompactPoseIndex(RequiredBones));

			}

		}


		if (test_counter < 10)
		{
			spine_between_transforms.Empty();

			spine_between_heights.Empty();
		}

		combined_indices.Empty();

		if (spine_Feet_pair.Num() > 1 && solve_should_fail==false)
		{

			TArray<FCompactPoseBoneIndex> BoneIndices;

			{
				const FCompactPoseBoneIndex RootIndex = spine_Feet_pair[0].Spine_Involved.GetCompactPoseIndex(*SavedBoneContainer);
				FCompactPoseBoneIndex BoneIndex = spine_Feet_pair[spine_Feet_pair.Num() - 1].Spine_Involved.GetCompactPoseIndex(*SavedBoneContainer);
				do
				{
					BoneIndices.Insert(BoneIndex, 0);

					//owning_skel->GetBoneIndex( owning_skel->GetParentBone(owning_skel->GetBoneName(BoneIndex.GetInt())));
					BoneIndex = FCompactPoseBoneIndex(owning_skel->GetBoneIndex(owning_skel->GetParentBone(owning_skel->GetBoneName(BoneIndex.GetInt()))));
				} while (BoneIndex != RootIndex);
				BoneIndices.Insert(BoneIndex, 0);
			}



			combined_indices = BoneIndices;

			if (test_counter < 10)
			{
				spine_between_transforms.AddDefaulted(combined_indices.Num() - 2);
				spine_hit_edges.AddDefaulted(combined_indices.Num() - 2);
				spine_between_offseted_transforms.AddDefaulted(combined_indices.Num() - 2);

				spine_between_heights.AddDefaulted(combined_indices.Num() - 2);

				snake_spine_positions.AddDefaulted(combined_indices.Num());
			}

		}

		if (test_counter < 10)
		spine_hit_between.AddDefaulted(spine_between_transforms.Num());





		




		if (dragon_input_data.Pelvis == dragon_input_data.Start_Spine)
		{
			solve_should_fail = true;
		}

		if (!dragon_bone_data.Start_Spine.IsValidToEvaluate(RequiredBones) || !dragon_bone_data.Pelvis.IsValidToEvaluate(RequiredBones))
			solve_should_fail = true;

		//	dragon_bone_data.FeetBones.Add(dragon_input_data.FeetBones.Num() );
		dragon_bone_data.FeetBones.Empty();

		for (int i = 0; i < dragon_input_data.FeetBones.Num(); i++)
		{
			//dragon_bone_data.FeetBones[i] = FBoneReference(dragon_input_data.FeetBones[i]);
			dragon_bone_data.FeetBones.Add(FBoneReference(dragon_input_data.FeetBones[i].Feet_Bone_Name));
			dragon_bone_data.FeetBones[i].Initialize(RequiredBones);

			if (dragon_bone_data.FeetBones[i].IsValidToEvaluate(RequiredBones))
				feet_is_empty = false;


		}


	}
}


TArray<FDragonData_SpineFeetPair> FAnimNode_DragonAimSolver::Swap_Spine_Pairs(TArray<FDragonData_SpineFeetPair>& test_list)
{



	bool is_swapped = false;

	do
	{
		is_swapped = false;

		for (int32 j = 1; j < test_list.Num(); j++)
		{

			for (int32 i = 1; i < test_list[j].Associated_Feet.Num(); i++)
			{
				if (test_list[j].Associated_Feet[i - 1].BoneIndex < test_list[j].Associated_Feet[i].BoneIndex)
				{
					FBoneReference temp = test_list[j].Associated_Feet[i - 1];
					test_list[j].Associated_Feet[i - 1] = test_list[j].Associated_Feet[i];
					test_list[j].Associated_Feet[i] = temp;


					FBoneReference temp_knee = test_list[j].Associated_Knees[i - 1];
					test_list[j].Associated_Knees[i - 1] = test_list[j].Associated_Knees[i];
					test_list[j].Associated_Knees[i] = temp_knee;

					if (!automatic_leg_make)
					{
						FBoneReference temp_thigh = test_list[j].Associated_Thighs[i - 1];
						test_list[j].Associated_Thighs[i - 1] = test_list[j].Associated_Thighs[i];
						test_list[j].Associated_Thighs[i] = temp_thigh;


						int temp_knee_order = test_list[j].order_index[i - 1];
						test_list[j].order_index[i - 1] = test_list[j].order_index[i];
						test_list[j].order_index[i] = temp_knee_order;
					}

					is_swapped = true;
				}


			}
		}

	} while (is_swapped == true);


	return test_list;

}


TArray<FName> FAnimNode_DragonAimSolver::BoneArrayMachine(int32 index, FName starting,FName knee,FName thigh, FName ending, bool is_foot)
{

	TArray<FName> spine_bones;

	int iteration_count = 0;

	spine_bones.Add(starting);

	if (is_foot == false)
	{
		FDragonData_SpineFeetPair data = FDragonData_SpineFeetPair();
		data.Spine_Involved = FBoneReference(starting);
		data.Spine_Involved.Initialize(*SavedBoneContainer);
		spine_Feet_pair.Add(data);



	}


	bool finish = false;

	do
	{


		if (is_foot)
		{
			if (Check_Loop_Exist(index,dragon_input_data.FeetBones[index].Feet_Trace_Offset,dragon_input_data.FeetBones[index].Feet_Heights, dragon_input_data.FeetBones[index].Knee_Direction_Offset,starting, knee,thigh , spine_bones[spine_bones.Num() - 1], Total_spine_bones))
			{
				return spine_bones;
			}
		}



		iteration_count++;
		spine_bones.Add(owning_skel->GetParentBone(spine_bones[iteration_count - 1]));


		if (is_foot == false)
		{

			FDragonData_SpineFeetPair data = FDragonData_SpineFeetPair();
			data.Spine_Involved = FBoneReference(spine_bones[spine_bones.Num() - 1]);
			data.Spine_Involved.Initialize(*SavedBoneContainer);
			spine_Feet_pair.Add(data);


		}


		if (spine_bones[spine_bones.Num() - 1] == ending && is_foot == false)
		{

			return spine_bones;
		}

	} while (iteration_count < 50 && finish == false);


	return spine_bones;


}


bool FAnimNode_DragonAimSolver::Check_Loop_Exist(int index,FVector feet_trace_offset,float feet_height,FVector knee_pole,FName start_bone, FName knee_bone, FName thigh_bone, FName input_bone, TArray<FName>& total_spine_bones)
{

	for (int32 i = 0; i<total_spine_bones.Num(); i++)
	{
		if (input_bone.ToString().TrimStartAndEnd().Equals(total_spine_bones[i].ToString().TrimStartAndEnd()))
		{
			if (spine_Feet_pair.Num() > i)
			{
				FDragonData_SpineFeetPair data = FDragonData_SpineFeetPair();
				data.Spine_Involved = FBoneReference(total_spine_bones[i]);
				data.Spine_Involved.Initialize(*SavedBoneContainer);

				FBoneReference foot_bone = FBoneReference(start_bone);
				foot_bone.Initialize(*SavedBoneContainer);
				data.Associated_Feet.Add(foot_bone);

				spine_Feet_pair[i].Spine_Involved = data.Spine_Involved;
				spine_Feet_pair[i].Associated_Feet.Add(foot_bone);
				spine_Feet_pair[i].Feet_Heights.Add(feet_height);
				spine_Feet_pair[i].feet_trace_offset.Add(feet_trace_offset);
				spine_Feet_pair[i].knee_direction_offset.Add(knee_pole);
				spine_Feet_pair[i].order_index.Add(index);


				//if (enable_solver == false)
				//if (!automatic_leg_make)
				{
					
					FBoneReference knee_bone_ref = FBoneReference(knee_bone);
					knee_bone_ref.Initialize(*SavedBoneContainer);
					spine_Feet_pair[i].Associated_Knees.Add(knee_bone_ref);

					FBoneReference thigh_bone_ref = FBoneReference(thigh_bone);
					thigh_bone_ref.Initialize(*SavedBoneContainer);
					spine_Feet_pair[i].Associated_Thighs.Add(thigh_bone_ref);
				}



			//	GEngine->AddOnScreenDebugMessage(-1, 10.01f, FColor::Red, "Bone Feet : " + spine_Feet_pair[i].Associated_Feet[spine_Feet_pair[i].Associated_Feet.Num()-1].BoneName.ToString());
			//	GEngine->AddOnScreenDebugMessage(-1, 10.01f, FColor::Red, "Knee Feet : " + spine_Feet_pair[i].Associated_Knees[spine_Feet_pair[i].Associated_Feet.Num() - 1].BoneName.ToString());
			//	GEngine->AddOnScreenDebugMessage(-1, 10.01f, FColor::Red, "Thigh Feet : " + spine_Feet_pair[i].Associated_Thighs[spine_Feet_pair[i].Associated_Feet.Num() - 1].BoneName.ToString());
			//	GEngine->AddOnScreenDebugMessage(-1, 10.01f, FColor::Red, "///////////////");


				return true;
			}
		}
	}

	return false;
}







FCollisionQueryParams FAnimNode_DragonAimSolver::getDefaultSpineColliParams(FName name, AActor *me, bool debug_mode)
{

	const FName TraceTag(name);

	FCollisionQueryParams RV_TraceParams = FCollisionQueryParams(FName(TEXT("RV_Trace")), true, me);
	RV_TraceParams.bTraceComplex = true;
//	RV_TraceParams.bTraceAsyncScene = true;
	RV_TraceParams.bReturnPhysicalMaterial = false;
	RV_TraceParams.TraceTag = TraceTag;

	//	if(debug_mode)
	//	me->GetWorld()->DebugDrawTraceTag = TraceTag;


	return RV_TraceParams;
}


void FAnimNode_DragonAimSolver::line_trace_func(USkeletalMeshComponent &skelmesh, FVector startpoint, FVector endpoint, FHitResult RV_Ragdoll_Hit, FName bone_text, FName trace_tag, FHitResult& Output, FLinearColor debug_color, bool debug_mode)
{


}





FVector ClampRotateVector(FVector input_position, FVector forward_vector_dir,FVector origin_location,float min_clamp_degrees,float max_clamp_degree, float hori_clamp_min,float hori_clamp_max, bool use_natural_rotations)
{
	float Magnitude = (origin_location - input_position).Size();

	FVector rot1_v = (forward_vector_dir).GetSafeNormal();
//	rot1_v = FVector::CrossProduct(FVector::UpVector, rot1_v);


	FVector rot2_v = (input_position - origin_location).GetSafeNormal();

	FVector rot3_v = rot2_v;
//	rot3_v.Y = 0;
//	rot3_v.Z = 0;

	float Degrees = UKismetMathLibrary::DegAcos(FVector::DotProduct(rot1_v,rot2_v));


	float Degrees_Vertical = UKismetMathLibrary::DegAcos(FVector::DotProduct(rot1_v, rot3_v));
	FVector Angle_Cross_Result = FVector::CrossProduct(rot2_v , rot1_v);
	float Dir = FVector::DotProduct(Angle_Cross_Result, FVector::CrossProduct(FVector::UpVector, rot1_v));
	float Alpha_Dir_Vertical = (Dir / 2) + 0.5f;

	float Degrees_Horizontal = UKismetMathLibrary::DegAcos(FVector::DotProduct(rot1_v, rot3_v));
	FVector Angle_Cross_Result_Horizontal = FVector::CrossProduct(rot2_v, rot1_v);
	float Dir_Horizontal = FVector::DotProduct(Angle_Cross_Result_Horizontal, FVector::UpVector);
	float Alpha_Dir_Horizontal = (Dir_Horizontal / 2)+0.5f;

//	float Max_Side_Angle = hori_clamp_max;
//	float Min_Side_Angle = hori_clamp_min;
	
	float Max_Vertical_Angle = max_clamp_degree;
	float Min_Vertical_Angle = min_clamp_degrees;
	
	Max_Vertical_Angle = use_natural_rotations ? Max_Vertical_Angle : FMath::Clamp<float>(Max_Vertical_Angle,-85,85);
	Min_Vertical_Angle = use_natural_rotations ? Min_Vertical_Angle : FMath::Clamp<float>(Min_Vertical_Angle, -85, 85); ;


	float Horizontal_Degree_Priority = ( FMath::Lerp<float>( FMath::Abs<float>(hori_clamp_min), FMath::Abs<float>(hori_clamp_max), FMath::Clamp<float>(Alpha_Dir_Horizontal, 0, 1)) );

	float Vertical_Degree_Priority = ( FMath::Lerp<float>( FMath::Abs<float>(Min_Vertical_Angle), FMath::Abs<float>(Max_Vertical_Angle), FMath::Clamp<float>(Alpha_Dir_Vertical, 0, 1)));



//	Dir = Dir > 0 ? 1:-1;

//	float selected_clamp_value = FMath::Lerp(FMath::Abs<float>(min_clamp_degrees), FMath::Abs<float>(max_clamp_degree),  FMath::Clamp<float>( Dir,0,1));
//	float selected_clamp_value = FMath::Abs<float>(max_clamp_degree);

	float selected_clamp_value = FMath::Lerp<float>(Vertical_Degree_Priority,Horizontal_Degree_Priority, FMath::Clamp<float>( FMath::Abs<float>(Dir_Horizontal), 0, 1));
	
	float Alpha = (selected_clamp_value / (FMath::Max<float>(selected_clamp_value, Degrees)));
	Alpha = FMath::Clamp<float>(Alpha, 0, 1);


//	GEngine->AddOnScreenDebugMessage(-1, 0.1f, FColor::Red, " Alpha : " + FString::SanitizeFloat(Alpha));


//	GEngine->AddOnScreenDebugMessage(-1, 0.1f, FColor::Red, " Dir : "+ FString::SanitizeFloat(Vertical_Degree_Priority) + " Dir_Horizontal : " + FString::SanitizeFloat(Horizontal_Degree_Priority));
	FVector output_rot = UKismetMathLibrary::VLerp(rot1_v , rot2_v, Alpha);
	return (origin_location + (output_rot.GetSafeNormal()* Magnitude));
}


void FAnimNode_DragonAimSolver::FABRIK_BodySystem(FCSPose<FCompactPose>& MeshBases, FComponentSpacePoseContext& Output, TArray<FBoneTransform>& OutBoneTransforms)
{


	if (toggle_alpha > 0.01f)
	{

		FTransform LookAtLocation_Temp = LookAtLocation;


		if (!owning_skel->GetWorld()->IsGameWorld())
			LookAtLocation_Temp = Debug_LookAtLocation;



		if (automatic_leg_make)
		{
			for (int spineindex = 0; spineindex < spine_Feet_pair.Num(); spineindex++)
			{
				for (int footindex = 0; footindex < spine_Feet_pair[spineindex].Associated_Feet.Num(); footindex++)
				{
					//	if (spine_Feet_pair[spineindex].Associated_Knees.Num()==0)
					{
						FCompactPoseBoneIndex Knee_Index = MeshBases.GetPose().GetParentBoneIndex(spine_Feet_pair[spineindex].Associated_Feet[footindex].CachedCompactPoseIndex);
						spine_Feet_pair[spineindex].Associated_Knees[footindex] = (FBoneReference(owning_skel->GetBoneName(Knee_Index.GetInt())));
						spine_Feet_pair[spineindex].Associated_Knees[footindex].Initialize(*SavedBoneContainer);

						FCompactPoseBoneIndex Thigh_Index = MeshBases.GetPose().GetParentBoneIndex(Knee_Index);
						spine_Feet_pair[spineindex].Associated_Thighs[footindex] = (FBoneReference(owning_skel->GetBoneName(Thigh_Index.GetInt())));
						spine_Feet_pair[spineindex].Associated_Thighs[footindex].Initialize(*SavedBoneContainer);

					}
				}
			}

		}




		if (enable_solver)
		{
			HeadTransforms.Empty();
			Ref_HeadTransforms.Empty();



			FAxis LookatAxis_Temp;
			LookatAxis_Temp.bInLocalSpace = false;
			LookatAxis_Temp.Axis = LookAt_Axis.GetSafeNormal();




			Head_Orig_Transform = MeshBases.GetComponentSpaceTransform(EndSplineBone.CachedCompactPoseIndex);




			//FVector target_dir = (LookAtLocation_Temp.GetLocation() - Head_Orig_Transform.GetLocation()).GetSafeNormal();
			//float Diff_Length = (LookAtLocation_Temp.GetLocation() - Head_Orig_Transform.GetLocation()).Size();			


			/*
			float AimClampInRadians_Temp = FMath::DegreesToRadians(FMath::Min(Lookat_Clamp, 180.f));
			float Angle_Of_Target = FMath::Acos(FVector::DotProduct(target_dir,LookatAxis_Temp.Axis));

			if (Angle_Of_Target < AimClampInRadians_Temp)
			{
				GEngine->AddOnScreenDebugMessage(-1, 0.01f, FColor::Red, " Angle_Of_Target " + FString::SanitizeFloat(Angle_Of_Target));

				LookAtLocation_Saved = LookAtLocation_Temp;
			}

		//	LookAtLocation_Temp.SetLocation( Head_Orig_Transform.GetLocation() + target_dir *Diff_Length );

		//	LookAtLocation_Temp = LookAtLocation_Saved;
			LookAtLocation_Temp.SetLocation(FVector(LookAtLocation_Temp.GetLocation().X, LookAtLocation_Saved.GetLocation().Y, LookAtLocation_Temp.GetLocation().Z));
			*/




			//|| (Lerped_LookatLocation-LookAtLocation_Temp.GetLocation()).Size() > 1000 

			if (Lerped_LookatLocation == FVector::ZeroVector)
				Lerped_LookatLocation = LookAtLocation_Temp.GetLocation();

			//	Lerped_LookatLocation = UKismetMathLibrary::VLerp(Lerped_LookatLocation,LookAtLocation_Temp.GetLocation(),owning_skel->GetWorld()->GetDeltaSeconds()* Interpolation_Speed);

			Lerped_LookatLocation = AnimLocLerp(Lerped_LookatLocation, LookAtLocation_Temp.GetLocation(), owning_skel->GetWorld()->GetDeltaSeconds() * Interpolation_Speed);

			//	AnimLocLerp(FVector start_pos, FVector end_pos, float delta_seconds);

			LookAtLocation_Temp.SetLocation(Lerped_LookatLocation);


			LookAtLocation_Temp.SetLocation(ClampRotateVector(LookAtLocation_Temp.GetLocation(), owning_skel->GetComponentToWorld().TransformVector(LookAt_Axis), owning_skel->GetComponentToWorld().TransformPosition(Head_Orig_Transform.GetLocation()), Verticle_Range_Angles.X, Verticle_Range_Angles.Y, Horizontal_Range_Angles.X, Horizontal_Range_Angles.Y, Use_Natural_Method));



			FTransform LookTargetTransform = FTransform();
			LookTargetTransform = (LookAtLocation_Temp);


			FAnimationRuntime::ConvertBoneSpaceTransformToCS(owning_skel->GetComponentToWorld(), MeshBases, LookTargetTransform, EndSplineBone.GetCompactPoseIndex(*SavedBoneContainer), EBoneControlSpace::BCS_WorldSpace);


			//	LookTargetTransform.SetLocation(ClampRotateVector(LookTargetTransform.GetLocation(), LookAt_Axis, Head_Orig_Transform.GetLocation(), Verticle_Range_Angles.X, Verticle_Range_Angles.Y));




				//	GEngine->AddOnScreenDebugMessage(-1, 0.01f, FColor::Red, " TEST ");





			UDragonIK_Library::Evaluate_ConsecutiveBoneRotations(Output, owning_skel, spine_Feet_pair, Look_Bending_Curve, StartSplineBone, EndSplineBone, Lookat_Radius, LookAtLocation_Temp, LookatAxis_Temp, Lookat_Radius, Downward_Dip_Multiplier, Side_Move_Multiplier, Side_Down_Multiplier, false, FTransform::Identity, Look_Multiplier_Curve, Up_Rot_Clamp, Use_Natural_Method, Head_Use_Separate_Clamp, Lookat_Clamp, HeadTransforms);
			//	Evaluate_ConsecutiveBoneRotations(FComponentSpacePoseContext & Output, USkeletalMeshComponent * owning_skel, FRuntimeFloatCurve Look_Bending_Curve, FBoneReference RootBone_Input, FBoneReference TipBone_Input, float Lookat_Radius, FTransform EffectorTransform, FAxis LookUp_Axis, FAxis LookAt_Axis, float Lookat_Clamp, FRotator HeadRotOffset, TArray<FBoneTransform> & OutBoneTransforms)

			//	UDragonIK_Library::Evaluate_CCDIK_Modified(Output, owning_skel, StartSplineBone, EndSplineBone, Precision, MaxIterations, true, true, Lookat_Radius, Lock_Forward_Axis, Lock_Side_Axis, Head_WSTransform, FabrikOffset, Ref_HeadTransforms);
			//	UDragonIK_Library::Evaluate_CCDIK_Modified(Output, owning_skel, StartSplineBone, EndSplineBone, Precision, MaxIterations, true, true, Lookat_Radius, Lock_Forward_Axis, Lock_Side_Axis, LookAtLocation, FabrikOffset, Ref_HeadTransforms);



				//	UDragonIK_Library::Evaluate_SplineIK_Modified(Output,owning_skel,CachedBoneReferences,ControlPoints,TransformedSpline,BoneSpline,LinearApproximation,Roll,TwistStart,TwistEnd,TwistBlend, HeadTransforms);

			/*
			if (Head_Use_Separate_Clamp)
			{

			//	FBoneTransform Lookat_Rotation_Rotator = LookAt_Processor(MeshBases, LookTargetTransform.GetLocation(), EndSplineBone.BoneName, HeadTransforms.Num() - 1, Lookat_Radius);

				FBoneTransform Lookat_Rotation_Rotator = HeadTransforms[HeadTransforms.Num()-1];

				HeadTransforms[HeadTransforms.Num() - 1] = Lookat_Rotation_Rotator;
				HeadTransforms[HeadTransforms.Num() - 1].Transform.SetRotation(LookAt_Processor(MeshBases, LookTargetTransform.GetLocation(), EndSplineBone.BoneName, HeadTransforms.Num() - 1, Lookat_Clamp).Transform.GetRotation());

			}*/



			TArray<FCompactPoseBoneIndex> HeadTransformPoses = TArray<FCompactPoseBoneIndex>();

			for (int transformindex = 0; transformindex < HeadTransforms.Num(); transformindex++)
			{
				HeadTransformPoses.Add(HeadTransforms[transformindex].BoneIndex);
			}



			//	FBoneReference foot_bone_ref = FBoneReference(spine_Feet_pair[0].Associated_Feet);
			//	foot_bone_ref.Initialize(*SavedBoneContainer);


			LegIK_Transforms.Empty();
			HandIK_Transforms.Empty();



			//FQuat Pelvis_Difference = RootBone_Transform.GetRotation().Inverse() * pelvis_transform.GetRotation();

			if (Lock_Legs)
				for (int i = 0; i < spine_Feet_pair.Num(); i++)
				{

					bool is_valid_bone = false;

					int common_bone_index = 0;

					for (int k = 0; k < HeadTransforms.Num(); k++)
					{
						if (spine_Feet_pair[i].Spine_Involved.BoneIndex == HeadTransforms[k].BoneIndex.GetInt())
						{
							is_valid_bone = true;

							common_bone_index = k;
						}
					}


					FTransform  RootBone_Transform = MeshBases.GetComponentSpaceTransform(HeadTransforms[common_bone_index].BoneIndex);
					FTransform pelvis_updated_transform = HeadTransforms[common_bone_index].Transform;


					if (is_valid_bone)
						for (int j = 0; j < spine_Feet_pair[i].Associated_Feet.Num(); j++)
						{

							//	GEngine->AddOnScreenDebugMessage(-1, 0.01f, FColor::Red, "Bone Feet : " + spine_Feet_pair[i].Associated_Feet[j].BoneName.ToString());
							//	GEngine->AddOnScreenDebugMessage(-1, 0.01f, FColor::Red, "Knee Feet : " + spine_Feet_pair[i].Associated_Knees[j].BoneName.ToString());
							//	GEngine->AddOnScreenDebugMessage(-1, 0.01f, FColor::Red, "Thigh Feet : " + spine_Feet_pair[i].Associated_Thighs[j].BoneName.ToString());
							//	GEngine->AddOnScreenDebugMessage(-1, 0.01f, FColor::Red, "///////////////" + spine_Feet_pair[i].Associated_Thighs[j].BoneName.ToString());


							if (spine_Feet_pair[i].Associated_Knees[j].IsValidToEvaluate() && spine_Feet_pair[i].Associated_Thighs[j].IsValidToEvaluate() && spine_Feet_pair[i].Associated_Feet.Num() > 0 && spine_Feet_pair[i].Associated_Knees.Num() > 0 && spine_Feet_pair[i].Associated_Thighs.Num() > 0)
							{

								FTransform  Thigh_Transform = MeshBases.GetComponentSpaceTransform(spine_Feet_pair[i].Associated_Thighs[j].CachedCompactPoseIndex);

								//FTransform  Thigh_Transform = DebugEffectorTransform * owning_skel->GetComponentToWorld().Inverse();


								FTransform Inv_Pelvis_Thigh = Thigh_Transform * RootBone_Transform.Inverse();

								Thigh_Transform = Inv_Pelvis_Thigh * HeadTransforms[common_bone_index].Transform;

								//	if (j > 10)

								if (dragon_input_data.FeetBones.Num() > spine_Feet_pair[i].order_index[j])
								{
									//	GEngine->AddOnScreenDebugMessage(-1, 0.01f, FColor::Red, "Knee_Direction_Offset Feet : " + FString::SanitizeFloat(spine_Feet_pair[i].order_index[j])+" at knee "+ spine_Feet_pair[i].Associated_Knees[j].BoneName.ToString());

									UDragonIK_Library::Evaluate_TwoBoneIK_Modified(Output, owning_skel, spine_Feet_pair[i].Associated_Feet[j], spine_Feet_pair[i].Associated_Knees[j], spine_Feet_pair[i].Associated_Thighs[j], Thigh_Transform, LookTargetTransform.GetLocation(), dragon_input_data.FeetBones[spine_Feet_pair[i].order_index[j]].Knee_Direction_Offset, LegIK_Transforms); //spine_Feet_pair[i].knee_direction_offset[j]


								}


							}


						}
				}





			//GEngine->AddOnScreenDebugMessage(-1, 0.01f, FColor::Red, "LegIK_Transforms value : " + FString::SanitizeFloat(LegIK_Transforms.Num()));



			FCompactPoseBoneIndex shoulder_spine_bone = FCompactPoseBoneIndex(0);



			if (!ignore_separate_hand_solving)
			{

				if (Main_Arm_Index > -1 && Main_Arm_Index < Hand_Array.Num())
				{


					if (Actual_Shoulder_Array[Main_Arm_Index].IsValidToEvaluate() && Elbow_Array[Main_Arm_Index].IsValidToEvaluate() && Hand_Array[Main_Arm_Index].IsValidToEvaluate())
					{

						//	FTransform  Shoulder_Transform = MeshBases.GetComponentSpaceTransform(Shoulder_Array[limb_index].CachedCompactPoseIndex);
						//	FTransform  Elbow_Transform = MeshBases.GetComponentSpaceTransform(Elbow_Array[limb_index].CachedCompactPoseIndex);
						//	FTransform  Hand_Transform = MeshBases.GetComponentSpaceTransform(Hand_Array[limb_index].CachedCompactPoseIndex);

						FCompactPoseBoneIndex Connector_Index = FCompactPoseBoneIndex(0);

						FTransform Common_Spine_Modified_Transform = FTransform::Identity;


						for (int body_index = 0; body_index < HeadTransforms.Num(); body_index++)
						{

							FCompactPoseBoneIndex First_Level = MeshBases.GetPose().GetParentBoneIndex(Actual_Shoulder_Array[Main_Arm_Index].CachedCompactPoseIndex);

							if (HeadTransforms[body_index].BoneIndex == First_Level)
							{
								Connector_Index = HeadTransforms[body_index].BoneIndex;

								Common_Spine_Modified_Transform = HeadTransforms[body_index].Transform;
							}


							FCompactPoseBoneIndex Second_Level = MeshBases.GetPose().GetParentBoneIndex(First_Level);

							if (HeadTransforms[body_index].BoneIndex == Second_Level)
							{
								Connector_Index = HeadTransforms[body_index].BoneIndex;

								Common_Spine_Modified_Transform = HeadTransforms[body_index].Transform;
							}


						}


						if (Connector_Index.GetInt() > 0)
						{


							FVector Target_CS_Position = owning_skel->GetComponentToWorld().InverseTransformPosition(LookAtLocation_Temp.GetLocation());

							Target_CS_Position += TargetOffset;


							FTransform  Common_Spine_Transform = MeshBases.GetComponentSpaceTransform(Connector_Index);
							FTransform Inv_Common_Spine = Common_Spine_Transform.Inverse() * Common_Spine_Modified_Transform;


							FTransform  Hand_Transform_Default = MeshBases.GetComponentSpaceTransform(Hand_Array[Main_Arm_Index].CachedCompactPoseIndex);
							FTransform  Shoulder_Transform_Default = MeshBases.GetComponentSpaceTransform(Actual_Shoulder_Array[Main_Arm_Index].CachedCompactPoseIndex);
							FTransform  Knee_Transform_Default = MeshBases.GetComponentSpaceTransform(Elbow_Array[Main_Arm_Index].CachedCompactPoseIndex);


							FTransform Hand_Transform = MeshBases.GetComponentSpaceTransform(Hand_Array[Main_Arm_Index].CachedCompactPoseIndex) * Inv_Common_Spine;
							FTransform Shoulder_Transform = MeshBases.GetComponentSpaceTransform(Actual_Shoulder_Array[Main_Arm_Index].CachedCompactPoseIndex) * Inv_Common_Spine;


							FTransform Shoulder_Offseted_Transform = Shoulder_Transform_Default;
							Shoulder_Offseted_Transform.SetLocation(Shoulder_Transform.GetLocation());

							float Individual_Leg_Clamp = Limbs_Clamp;

							if (Aiming_Hand_Limbs[Main_Arm_Index].overridden_limb_clamp > 0)
								Individual_Leg_Clamp = Aiming_Hand_Limbs[Main_Arm_Index].overridden_limb_clamp;

							FVector X_Diff = Shoulder_Transform.GetLocation() - Common_Spine_Transform.GetLocation();
							FTransform Rotated_Shoulder = UDragonIK_Library::LookAt_Processor(Shoulder_Offseted_Transform, Common_Spine_Transform.GetLocation(), Target_CS_Position, LookatAxis_Temp, Individual_Leg_Clamp, Use_Natural_Method, 1, 1);
							FTransform Inv_Shoulder_Value = Shoulder_Transform_Default.Inverse() * Rotated_Shoulder;

							FTransform Shoulder_Transform_Output = Shoulder_Transform_Default * Inv_Shoulder_Value;
							FTransform Knee_Transform_Output = Knee_Transform_Default * Inv_Shoulder_Value;
							FTransform Hand_Transform_Output = Hand_Transform_Default * Inv_Shoulder_Value;


							FVector Arm_Vector = (Hand_Transform_Output.GetLocation() - Shoulder_Transform_Output.GetLocation());
							float Arm_Length = Arm_Vector.Size();
							float Target_Arm_Length = (Common_Spine_Modified_Transform.GetLocation() - Target_CS_Position).Size();

							Target_Arm_Length = FMath::Clamp<float>(Target_Arm_Length, 1, Arm_Length);
							Hand_Transform.SetLocation(Shoulder_Transform_Output.GetLocation() + Arm_Vector.GetSafeNormal() * Target_Arm_Length);

							Common_Spine_Transform.SetLocation(Target_CS_Position);

							if (!ignore_elbow_modification)
							{

								UDragonIK_Library::Evaluate_TwoBoneIK_Direct_Modified(Output, owning_skel, Hand_Array[Main_Arm_Index], Elbow_Array[Main_Arm_Index], Actual_Shoulder_Array[Main_Arm_Index], Hand_Transform, Shoulder_Transform_Output, Knee_Transform_Output, Hand_Transform_Output, FVector(0, 0, 0), FVector(0, 0, 0), Inv_Common_Spine, Common_Spine_Transform, Limb_Rotation_Offset, Aiming_Hand_Limbs[Main_Arm_Index].Local_Direction_Axis, Aiming_Hand_Limbs[Main_Arm_Index].relative_axis, Individual_Leg_Clamp, Aiming_Hand_Limbs[Main_Arm_Index].accurate_hand_rotation,FTransform::Identity, HandIK_Transforms);

								Main_Hand_New_Transform = HandIK_Transforms[2].Transform;

								Main_Hand_Default_Transform = Hand_Transform_Default;

							}
							else
								HandIK_Transforms.Add(FBoneTransform(Actual_Shoulder_Array[Main_Arm_Index].CachedCompactPoseIndex, Rotated_Shoulder));

						}


					}


				}



				for (int limb_index = 0; limb_index < Aiming_Hand_Limbs.Num(); limb_index++)
				{

					Actual_Shoulder_Array[limb_index] = Shoulder_Array[limb_index];
					const FBoneReference Original_BoneRef = Actual_Shoulder_Array[limb_index];
					FCompactPoseBoneIndex current_parent = Actual_Shoulder_Array[limb_index].CachedCompactPoseIndex;
					FCompactPoseBoneIndex Last_Saved_Bone = current_parent;

					bool Found_Limbs = false;


					for (int i = 0; i < 5; i++)
					{
						if (Actual_Shoulder_Array[limb_index].BoneIndex > 0)
						{
							//GEngine->AddOnScreenDebugMessage(-1, 0.1f, FColor::Red, " Last_Saved_Bone[limb_index] : " + Actual_Shoulder_Array[limb_index].BoneName.ToString());

							Last_Saved_Bone = Actual_Shoulder_Array[limb_index].GetCompactPoseIndex(*SavedBoneContainer);
							FCompactPoseBoneIndex Ref_Parent = MeshBases.GetPose().GetParentBoneIndex(Last_Saved_Bone);
							//current_parent = MeshBases.GetPose().GetParentBoneIndex(Actual_Shoulder_Array[limb_index].CachedCompactPoseIndex);


							if (HeadTransformPoses.Contains(Ref_Parent))
							{
								break;
							}


							//if (Spine_Index_Ref == current_parent)
							{
								Found_Limbs = true;


								//	Actual_Shoulder_Array[limb_index] = FBoneReference(owning_skel->GetBoneName(Last_Saved_Bone.GetInt()));
								Actual_Shoulder_Array[limb_index] = FBoneReference(owning_skel->GetBoneName(current_parent.GetInt()));
								Actual_Shoulder_Array[limb_index].Initialize(*SavedBoneContainer);
								current_parent = MeshBases.GetPose().GetParentBoneIndex(Actual_Shoulder_Array[limb_index].GetCompactPoseIndex(*SavedBoneContainer));

							}

						}
						else
						{
							break;
						}
					}
				}


				for (int limb_index = 0; limb_index < Aiming_Hand_Limbs.Num(); limb_index++)
				{

					//	GEngine->AddOnScreenDebugMessage(-1, 0.1f, FColor::Red, " Actual_Shoulder_Array[limb_index] : "+ Actual_Shoulder_Array[limb_index].BoneName.ToString());



					if (Actual_Shoulder_Array[limb_index].IsValidToEvaluate() && Elbow_Array[limb_index].IsValidToEvaluate() && Hand_Array[limb_index].IsValidToEvaluate() && (limb_index != Main_Arm_Index || Main_Arm_Index < 0))
					{

						//	FTransform  Shoulder_Transform = MeshBases.GetComponentSpaceTransform(Shoulder_Array[limb_index].CachedCompactPoseIndex);
						//	FTransform  Elbow_Transform = MeshBases.GetComponentSpaceTransform(Elbow_Array[limb_index].CachedCompactPoseIndex);
						//	FTransform  Hand_Transform = MeshBases.GetComponentSpaceTransform(Hand_Array[limb_index].CachedCompactPoseIndex);

						FCompactPoseBoneIndex Connector_Index = FCompactPoseBoneIndex(0);

						FTransform Common_Spine_Modified_Transform = FTransform::Identity;


						for (int body_index = 0; body_index < HeadTransforms.Num(); body_index++)
						{

							FCompactPoseBoneIndex First_Level = MeshBases.GetPose().GetParentBoneIndex(Actual_Shoulder_Array[limb_index].CachedCompactPoseIndex);

							if (HeadTransforms[body_index].BoneIndex == First_Level)
							{
								Connector_Index = HeadTransforms[body_index].BoneIndex;

								Common_Spine_Modified_Transform = HeadTransforms[body_index].Transform;
							}


							FCompactPoseBoneIndex Second_Level = MeshBases.GetPose().GetParentBoneIndex(First_Level);

							if (HeadTransforms[body_index].BoneIndex == Second_Level)
							{
								Connector_Index = HeadTransforms[body_index].BoneIndex;

								Common_Spine_Modified_Transform = HeadTransforms[body_index].Transform;
							}


						}


						if (Connector_Index.GetInt() > 0)
						{


							FVector Target_CS_Position = owning_skel->GetComponentToWorld().InverseTransformPosition(LookAtLocation_Temp.GetLocation());

							Target_CS_Position += TargetOffset;


							FTransform  Common_Spine_Transform = MeshBases.GetComponentSpaceTransform(Connector_Index);
							FTransform Inv_Common_Spine = Common_Spine_Transform.Inverse() * Common_Spine_Modified_Transform;


							FTransform  Hand_Transform_Default = MeshBases.GetComponentSpaceTransform(Hand_Array[limb_index].CachedCompactPoseIndex);
							FTransform  Shoulder_Transform_Default = MeshBases.GetComponentSpaceTransform(Actual_Shoulder_Array[limb_index].CachedCompactPoseIndex);
							FTransform  Knee_Transform_Default = MeshBases.GetComponentSpaceTransform(Elbow_Array[limb_index].CachedCompactPoseIndex);


							FTransform Hand_Transform = MeshBases.GetComponentSpaceTransform(Hand_Array[limb_index].CachedCompactPoseIndex) * Inv_Common_Spine;
							FTransform Shoulder_Transform = MeshBases.GetComponentSpaceTransform(Actual_Shoulder_Array[limb_index].CachedCompactPoseIndex) * Inv_Common_Spine;


							FTransform Shoulder_Offseted_Transform = Shoulder_Transform_Default;
							Shoulder_Offseted_Transform.SetLocation(Shoulder_Transform.GetLocation());

							float Individual_Leg_Clamp = Limbs_Clamp;

							if (Aiming_Hand_Limbs[limb_index].overridden_limb_clamp > 0)
								Individual_Leg_Clamp = Aiming_Hand_Limbs[limb_index].overridden_limb_clamp;

							FVector X_Diff = Shoulder_Transform.GetLocation() - Common_Spine_Transform.GetLocation();
							FTransform Rotated_Shoulder = UDragonIK_Library::LookAt_Processor(Shoulder_Offseted_Transform, Common_Spine_Transform.GetLocation(), Target_CS_Position, LookatAxis_Temp, Individual_Leg_Clamp, Use_Natural_Method, 1, 1);
							FTransform Inv_Shoulder_Value = Shoulder_Transform_Default.Inverse() * Rotated_Shoulder;

							FTransform Shoulder_Transform_Output = Shoulder_Transform_Default * Inv_Shoulder_Value;
							FTransform Knee_Transform_Output = Knee_Transform_Default * Inv_Shoulder_Value;
							FTransform Hand_Transform_Output = Hand_Transform_Default * Inv_Shoulder_Value;


							FVector Arm_Vector = (Hand_Transform_Output.GetLocation() - Shoulder_Transform_Output.GetLocation());
							float Arm_Length = Arm_Vector.Size();
							float Target_Arm_Length = (Common_Spine_Modified_Transform.GetLocation() - Target_CS_Position).Size();

							Target_Arm_Length = FMath::Clamp<float>(Target_Arm_Length, 1, Arm_Length);
							Hand_Transform.SetLocation(Shoulder_Transform_Output.GetLocation() + Arm_Vector.GetSafeNormal() * Target_Arm_Length);

							Common_Spine_Transform.SetLocation(Target_CS_Position);

							if (!ignore_elbow_modification)
							{

								//	FTransform Main_Hand_Default_Transform;Main_Hand_New_Transform

								//    FTransform Main_Relative_Transform =   Hand_Transform_Default * Main_Hand_Default_Transform.Inverse();
								//	Main_Relative_Transform = FTransform::Identity;
								//	FTransform Offseted_Hand_Transform = Main_Hand_New_Transform + Main_Relative_Transform;


								FTransform Main_Relative_Transform = (Main_Hand_Default_Transform.Inverse() * Main_Hand_New_Transform);
								FTransform Offseted_Hand_Transform = Hand_Transform_Default * Main_Relative_Transform;

								if (Main_Arm_Index < 0)
								{
									Main_Relative_Transform = FTransform::Identity;
									Offseted_Hand_Transform = Hand_Transform;
								}

								//Offseted_Hand_Transform.AddToTranslation( ( Main_Hand_Default_Transform.Inverse() * Hand_Transform_Default).GetLocation() );

								UDragonIK_Library::Evaluate_TwoBoneIK_Direct_Modified(Output, owning_skel, Hand_Array[limb_index], Elbow_Array[limb_index], Actual_Shoulder_Array[limb_index], Offseted_Hand_Transform, Shoulder_Transform_Output, Knee_Transform_Output, Hand_Transform_Output, FVector(0, 0, 0), FVector(0, 0, 0), Inv_Common_Spine, Common_Spine_Transform, Limb_Rotation_Offset, Aiming_Hand_Limbs[limb_index].Local_Direction_Axis, Aiming_Hand_Limbs[limb_index].relative_axis, Individual_Leg_Clamp, Aiming_Hand_Limbs[limb_index].accurate_hand_rotation, Main_Relative_Transform, HandIK_Transforms);

							}
							else
								HandIK_Transforms.Add(FBoneTransform(Actual_Shoulder_Array[limb_index].CachedCompactPoseIndex, Rotated_Shoulder));

						}


					}


				}

			}


		}

	}
}





FVector FAnimNode_DragonAimSolver::AnimLocLerp(FVector start_pos, FVector end_pos, float delta_seconds)
{
	FVector start_pos_val = start_pos;
	FVector end_pos_val = end_pos;
	FVector vector_difference = (start_pos_val - end_pos_val) / FMath::Clamp<float>(100 - (Interpolation_Speed * delta_seconds * 12), 1, 100);

	FVector output = FVector::ZeroVector;

	if(loc_interp_type == EInterpoLocation_Type_Plugin::ENUM_DivisiveLoc_Interp)
	output = (start_pos_val - vector_difference);
	else
	output = UKismetMathLibrary::VLerp(start_pos_val,end_pos_val,delta_seconds*0.5f);

	return output;
}



FBoneTransform FAnimNode_DragonAimSolver::LookAt_Processor(FCSPose<FCompactPose>& MeshBases, FVector Offset_Vector, FName bone_name, int index, float Lookat_Clamp_Param)
{



	const FCompactPoseBoneIndex ModifyBoneIndex = EndSplineBone.GetCompactPoseIndex(*SavedBoneContainer);
	FTransform ComponentBoneTransform = MeshBases.GetComponentSpaceTransform(ModifyBoneIndex);



	if (HeadTransforms.Num() > 0)
		ComponentBoneTransform.SetLocation(HeadTransforms[index].Transform.GetLocation());



	FVector TargetLocationInComponentSpace = Offset_Vector;


	//TargetLocationInComponentSpace += (TargetOffset);

	FAxis LookatAxis_Temp;
	LookatAxis_Temp.bInLocalSpace = false;
	LookatAxis_Temp.Axis = LookAt_Axis.GetSafeNormal();

	// lookat vector
	FVector LookAtVector = LookatAxis_Temp.GetTransformedAxis(ComponentBoneTransform).GetSafeNormal();
	// find look up vector in local space

	// Find new transform from look at info
	//FQuat DeltaRotation = AnimationCore::SolveAim(ComponentBoneTransform, TargetLocationInComponentSpace, LookAtVector, false, LookUpVector, Lookat_Clamp);


	//COMPARISON MODE



	FVector target_dir = (TargetLocationInComponentSpace - ComponentBoneTransform.GetLocation()).GetSafeNormal();
	float AimClampInRadians = FMath::DegreesToRadians(FMath::Min(Lookat_Clamp_Param, 180.f));
	float DiffAngle = FMath::Acos(FVector::DotProduct(LookAtVector, target_dir));

	if (DiffAngle > AimClampInRadians)
	{

		check(DiffAngle > 0.f);

		FVector DeltaTarget = target_dir - LookAtVector;
		// clamp delta target to within the ratio
		DeltaTarget *= (AimClampInRadians / DiffAngle);
		// set new target
		target_dir = LookAtVector + DeltaTarget;
		target_dir.Normalize();
	}

	//GEngine->AddOnScreenDebugMessage(-1, 0.1f, FColor::Red, " DiffAngle[0] : " +FString::SanitizeFloat(DiffAngle)+" AimClampInRadians : "+ FString::SanitizeFloat(AimClampInRadians));


	//FRotator Rot_Ref_01 = UDragonIK_Library::CustomLookRotation(target_dir, FVector(0, 0, -1));

	//	FRotator Rot_Ref_01 = UDragonIK_Library::CustomLookRotation( (TargetLocationInComponentSpace - ComponentBoneTransform.GetLocation() ).GetSafeNormal(), FVector(0, 0, -1));

	//FRotator Rot_Ref_02 = UDragonIK_Library::CustomLookRotation(LookAtVector, FVector(0, 0, -1));



	//	FQuat Normalized_Delta = FQuat::FindBetweenNormals(LookAtVector , (TargetLocationInComponentSpace - ComponentBoneTransform.GetLocation()).GetSafeNormal());


	FQuat Normalized_Delta = FQuat::FindBetweenNormals(LookAtVector, target_dir);

	/*
	if (!Use_Natural_Method)
	{
	//	FRotator Rot_Ref_01 = UDragonIK_Library::CustomLookRotation(target_dir, FVector(0, 0, -1));
	//	FRotator Rot_Ref_02 = UDragonIK_Library::CustomLookRotation(LookAtVector, FVector(0, 0, -1));
	//	Normalized_Delta = UKismetMathLibrary::NormalizedDeltaRotator(Rot_Ref_01, Rot_Ref_02).Quaternion();

		Normalized_Delta = UKismetMathLibrary::NormalizedDeltaRotator(target_dir.ToOrientationRotator(), LookAtVector.ToOrientationRotator()).Quaternion();

		FRotator temp_ND = FRotator(Normalized_Delta);

		if (LookAtVector == FVector(0.0f, 1.0f, 0.0f))
			Normalized_Delta = FRotator(-temp_ND.Roll, temp_ND.Yaw, -temp_ND.Pitch).Quaternion();
		else
			if (LookAtVector == FVector(0.0f, -1.0f, 0.0f))
				Normalized_Delta = FRotator(temp_ND.Roll, temp_ND.Yaw, temp_ND.Pitch).Quaternion();
			else
				if (LookAtVector == FVector(-1.0f, 0.0f, 0.0f))
					Normalized_Delta = FRotator(-temp_ND.Pitch, temp_ND.Yaw, -temp_ND.Roll).Quaternion();
				else
					if (LookAtVector == FVector(1.0f, 0.0f, 0.0f))
						Normalized_Delta = FRotator(temp_ND.Pitch, temp_ND.Yaw, temp_ND.Roll).Quaternion();
					else
						Normalized_Delta = FRotator(-temp_ND.Roll, temp_ND.Yaw, -temp_ND.Pitch).Quaternion();
	}
	*/
	/*
		FQuat Normalized_Delta = UKismetMathLibrary::NormalizedDeltaRotator(Rot_Ref_01, Rot_Ref_02).Quaternion();

		FVector Quat_Euler = Normalized_Delta.Euler();


		Quat_Euler.X = FMath::Clamp<float>(Quat_Euler.X, -Lookat_Clamp, Lookat_Clamp);
		Quat_Euler.Y = FMath::Clamp<float>(Quat_Euler.Y, -Lookat_Clamp, Lookat_Clamp);
		Quat_Euler.Z = FMath::Clamp<float>(Quat_Euler.Z, -Lookat_Clamp, Lookat_Clamp);



		Normalized_Delta =  FQuat::MakeFromEuler(Quat_Euler);
		*/

	FTransform World_Rotatation_Transform = ComponentBoneTransform;

	World_Rotatation_Transform.SetRotation(Normalized_Delta);

	FAnimationRuntime::ConvertCSTransformToBoneSpace(owning_skel->GetComponentToWorld(), MeshBases, World_Rotatation_Transform, ModifyBoneIndex, EBoneControlSpace::BCS_WorldSpace);


	FAnimationRuntime::ConvertBoneSpaceTransformToCS(owning_skel->GetComponentToWorld(), MeshBases, World_Rotatation_Transform, ModifyBoneIndex, EBoneControlSpace::BCS_WorldSpace);

	//FVector World_Euler_Rot = World_Rotatation_Transform.Rotator().Euler();
	 //World_Rotatation_Transform.SetRotation(FRotator(FMath::Clamp <float>(World_Rotatation_Transform.Rotator().Pitch, -Lookat_Clamp, Lookat_Clamp), FMath::Clamp <float>(World_Rotatation_Transform.Rotator().Yaw, -Lookat_Clamp, Lookat_Clamp), FMath::Clamp <float>(World_Rotatation_Transform.Rotator().Roll, -Lookat_Clamp, Lookat_Clamp)).Quaternion());

	// World_Rotatation_Transform.SetRotation(FRotator::MakeFromEuler(FVector( FMath::FMath::Abs<float>(World_Euler_Rot.X), FMath::FMath::Abs<float>(World_Euler_Rot.Y), FMath::FMath::Abs<float>(World_Euler_Rot.Z) )).Quaternion());

//	if (DiffAngle < AimClampInRadians)
	{

		ComponentBoneTransform.SetRotation(World_Rotatation_Transform.GetRotation() * ComponentBoneTransform.GetRotation());

		//	GEngine->AddOnScreenDebugMessage(-1, 0.1f, FColor::Red, " World_Rotatation_Transform : " + World_Rotatation_Transform.Rotator().ToString());


		//	ComponentBoneTransform.SetRotation(DeltaRotation * ComponentBoneTransform.GetRotation());




	}



	return (FBoneTransform(ModifyBoneIndex, ComponentBoneTransform));


}



FTransform FAnimNode_DragonAimSolver::LookAtAroundPoint(FVector direction,FVector AxisVector,float AngleAxis,FVector origin)
{
	FVector RotateValue = UKismetMathLibrary::RotateAngleAxis(direction, AngleAxis, AxisVector);



	//FVector RotateValue = Dimensions.RotateAngleAxis(AngleAxis, AxisVector);

	origin += RotateValue;

	FTransform result = FTransform();

	result.SetLocation(origin);

	return result;
}




void FAnimNode_DragonAimSolver::Dragon_VectorCreation(bool isPelvis, FTransform &OutputTransform, FCSPose<FCompactPose>& MeshBases)
{

	


}









FVector FAnimNode_DragonAimSolver::SmoothApproach(FVector pastPosition, FVector pastTargetPosition, FVector targetPosition, float speed)
{
	float t = owning_skel->GetWorld()->DeltaTimeSeconds * speed;
	FVector v = (targetPosition - pastTargetPosition) / t;
	FVector f = pastPosition - pastTargetPosition + v;
	return targetPosition - v + f * FMath::Exp(-t);
}

FVector FAnimNode_DragonAimSolver::RotateAroundPoint(FVector input_point, FVector forward_vector, FVector origin_point, float angle)
{
	FVector orbit_direction;

	orbit_direction = input_point - origin_point;

	FVector axis_dir = UKismetMathLibrary::RotateAngleAxis(orbit_direction, angle, forward_vector);

	FVector result_vector = input_point + (axis_dir - orbit_direction);

	return result_vector;

}




void FAnimNode_DragonAimSolver::OrthoNormalize(FVector& Normal, FVector& Tangent)
{
	Normal = Normal.GetSafeNormal();
	Tangent = Tangent - (Normal * FVector::DotProduct(Tangent, Normal));
	Tangent = Tangent.GetSafeNormal();
}

FQuat FAnimNode_DragonAimSolver::LookRotation(FVector lookAt, FVector upDirection) {

	FVector forward = lookAt;
	FVector up = upDirection;

	OrthoNormalize(forward, up);


	FVector right = FVector::CrossProduct(up, forward);

#define m00 right.X

#define m01 up.X

#define m02 forward.X

#define m10 right.Y

#define m11 up.Y

#define m12 forward.Y

#define m20 right.Z

#define m21 up.Z

#define m22 forward.Z



	float num8 = (m00 + m11) + m22;
	FQuat quaternion = FQuat();
	if (num8 > 0.0f)
	{
		float num = (float)FMath::Sqrt(num8 + 1.0f);
		quaternion.W = num * 0.5f;
		num = 0.5f / num;
		quaternion.X = (m12 - m21) * num;
		quaternion.Y = (m20 - m02) * num;
		quaternion.Z = (m01 - m10) * num;
		return quaternion;
	}
	if ((m00 >= m11) && (m00 >= m22))
	{
		float num7 = (float)FMath::Sqrt(((1.0f + m00) - m11) - m22);
		float num4 = 0.5f / num7;
		quaternion.X = 0.5f * num7;
		quaternion.Y = (m01 + m10) * num4;
		quaternion.Z = (m02 + m20) * num4;
		quaternion.W = (m12 - m21) * num4;
		return quaternion;
	}
	if (m11 > m22)
	{
		float num6 = (float)FMath::Sqrt(((1.0f + m11) - m00) - m22);
		float num3 = 0.5f / num6;
		quaternion.X = (m10 + m01) * num3;
		quaternion.Y = 0.5f * num6;
		quaternion.Z = (m21 + m12) * num3;
		quaternion.W = (m20 - m02) * num3;
		return quaternion;
	}
	float num5 = (float)FMath::Sqrt(((1.0f + m22) - m00) - m11);
	float num2 = 0.5f / num5;
	quaternion.X = (m20 + m02) * num2;
	quaternion.Y = (m21 + m12) * num2;
	quaternion.Z = 0.5f * num5;
	quaternion.W = (m01 - m10) * num2;



#undef m00

#undef m01

#undef m02

#undef m10

#undef m11

#undef m12

#undef m20

#undef m21

#undef m22

	return quaternion;

	//	return ret;

}




FVector FAnimNode_DragonAimSolver::GetCurrentLocation(FCSPose<FCompactPose>& MeshBases, const FCompactPoseBoneIndex& BoneIndex)
{
	return MeshBases.GetComponentSpaceTransform(BoneIndex).GetLocation();
}

